package com.example.phoneinformationShikha;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Toast;

import com.example.phoneinformation.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    boolean isConnected=false;
    int status=0;
    boolean isCharging=false;
    int chargePercent=0;
    long timestamp=1;
    double latitude=0.000;
    double longitude=0.000;
    FirebaseStorage storage;
    StorageReference storageReference;
    MyModel model;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Bitmap photo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        getData();
        initview();
        binding.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePicture();
            }
        });
        binding.btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                savedata();
                if (photo!=null){
                    try {
                        uploadImage(bitmapToUri(MainActivity.this,photo));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "Please Click image after upload!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        setContentView(binding.getRoot());
    }
    private void takePicture() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 101);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == RESULT_OK) {
            photo = (Bitmap) data.getExtras().get("data");
            binding.img.setImageBitmap(photo);
        }
    }
    private void initview() {
        model= new MyModel();
        firebaseDatabase = FirebaseDatabase.getInstance();
        final Handler handler = new Handler();
        Runnable runnableCode = new Runnable() {
            @Override
            public void run() {
                getData();
                savedata();
                if (photo!=null){
                    try {
                        uploadImage(bitmapToUri(MainActivity.this,photo));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "Please Click image after upload!!", Toast.LENGTH_SHORT).show();
                }
                 handler.postDelayed(this, 60000*15);
            }
        };
        handler.post(runnableCode);
    }
    private void savedata(){
        databaseReference = firebaseDatabase.getReference("user/"+getDeviceId(MainActivity.this));
        model.setImei(getDeviceId(MainActivity.this));
        model.setCharging_percentage(""+chargePercent);
        model.setConnectivity_status(""+isConnected);
        model.setCharging_status(""+isCharging);
        model.setTimestamp(""+timestamp);
        model.setLocation(""+binding.tv1.getText().toString());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(model);
                Toast.makeText(MainActivity.this, "success", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @SuppressLint("HardwareIds")
    public static String getDeviceId(Context context) {
        String deviceId;

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            deviceId = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
        } else {
            final TelephonyManager mTelephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (mTelephony.getDeviceId() != null) {
                deviceId = mTelephony.getDeviceId();
            } else {
                deviceId = Settings.Secure.getString(
                        context.getContentResolver(),
                        Settings.Secure.ANDROID_ID);
            }
        }

        return deviceId;
    }
    void getData(){
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE)
                == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            isConnected = networkInfo != null && networkInfo.isConnected();
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL;
            chargePercent = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            String provider = locationManager.getBestProvider(criteria, true);
            Location location = locationManager.getLastKnownLocation(provider);
            timestamp = location.getTime();
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            binding.tv.setText("Device Id :"+getDeviceId(MainActivity.this)+"\nInternet connectivity status : "+isConnected+ "\n Battery charging status :"+isCharging+" \n Timestamp : "+timestamp+"\n Battery charge : "+chargePercent+"%");
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                if (addresses.size() > 0) {
                    Address address = addresses.get(0);
                    String location1 = "Location : "+address.getLocality() + ", " + address.getAdminArea() + ", " + address.getCountryName();
                    binding.tv1.setText(location1);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_PHONE_STATE, android.Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        }

    }
    private void uploadImage(Uri filePath)
    {if (filePath != null) {
        ProgressDialog progressDialog = new ProgressDialog(this);progressDialog.setTitle("Uploading...");progressDialog.show();
        storage = FirebaseStorage.getInstance();
        StorageReference  storageRef = storage.getReference();
        StorageReference imageRef = storageRef.child("images/"+UUID.randomUUID().toString()+".png");
//        StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
        imageRef.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                    {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Image Uploaded!!", Toast.LENGTH_SHORT).show();
                    }
                })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e)
                    {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Failed " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot)
                    {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Uploaded " + (int)progress + "%");
                    }
                });
    }else {
        Toast.makeText(this, "file not upload", Toast.LENGTH_SHORT).show();
    }
    }
    public Uri bitmapToUri(Context context, Bitmap bitmap) throws IOException {
        File imageFile = new File(context.getCacheDir(), "image.jpg");
        FileOutputStream fos = new FileOutputStream(imageFile);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        fos.close();
        Uri imageUri = Uri.fromFile(imageFile);
        return imageUri;
    }
}