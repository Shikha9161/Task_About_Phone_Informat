package com.example.phoneinformationShikha;

public class MyModel {
    String imei;
    String connectivity_status;
    String charging_status;
    String charging_percentage;
    String location;
    String Timestamp;
    public MyModel(){

    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getConnectivity_status() {
        return connectivity_status;
    }

    public void setConnectivity_status(String connectivity_status) {
        this.connectivity_status = connectivity_status;
    }

    public String getCharging_status() {
        return charging_status;
    }

    public void setCharging_status(String charging_status) {
        this.charging_status = charging_status;
    }

    public String getCharging_() {
        return charging_percentage;
    }

    public void setCharging_percentage(String charging_) {
        this.charging_percentage = charging_;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTimestamp() {
        return Timestamp;
    }

    public void setTimestamp(String timestamp) {
        Timestamp = timestamp;
    }

    public MyModel(String imei, String connectivity_status, String charging_status, String charging_, String location, String timestamp) {
        this.imei = imei;
        this.connectivity_status = connectivity_status;
        this.charging_status = charging_status;
        this.charging_percentage = charging_;
        this.location = location;
        Timestamp = timestamp;
    }
}
